object WorkerLauncher {
  import scala.reflect.ClassTag
  import akka.actor.{Props,Actor,ActorSystem,Deploy,Address}
  import akka.remote.RemoteScope

  def main(args: Array[String]) { // WorkerLauncher <port=2552> <host=127.0.0.1> <name=DDBT>
    val port = if (args.length>0) args(0).toInt else 2552
    val host = if (args.length>1) args(1) else "127.0.0.1"
    val name = if (args.length>2) args(2) else "ddbt"
    system(name,host,port)
  }
  def system(name:String,host:String,port:Int) = {
    val conf = "akka {\nactor.provider=\"akka.remote.RemoteActorRefProvider\"\nremote.netty {\nhostname=\""+host+"\"\ntcp.port="+port+"\n}\n}\n"
    val system = ActorSystem(name, com.typesafe.config.ConfigFactory.parseString(conf))
    Runtime.getRuntime.addShutdownHook(new Thread{ override def run() = { println("Stopping "+host+":"+port); system.shutdown() } });
    println("Started "+host+":"+port); system
  }
  def remoteProps[A<:Actor](name:String,host:String,port:Int)(implicit cA:ClassTag[A]) = {
    Props(cA.runtimeClass).withDeploy(Deploy(scope = RemoteScope(new Address("akka.tcp",name,host,port))))
  }
}

// ---------------------------------------------------------

import akka.actor.{ Props, Actor, ActorSystem, ActorRef }
import com.typesafe.config.ConfigFactory
import scala.util.Random

class CreationActor(remoteActor: ActorRef) extends Actor {
  def receive = {
    case op: MathOp => remoteActor ! op
    case result: MathResult => result match {
      case MultiplicationResult(n1, n2, r) => printf("Mul result: %d * %d = %d\n", n1, n2, r)
      case DivisionResult(n1, n2, r) => printf("Div result: %.0f / %d = %.2f\n", n1, n2, r)
    }
  }
}

object CreationApp {
  val system = WorkerLauncher.system("RemoteCreation","127.0.0.1",2554)
  val p = WorkerLauncher.remoteProps[AdvancedCalculatorActor]("ddbt","127.0.0.1",2552)
  val remoteActor = system.actorOf(p /*, name = "advancedCalculator"*/ )

  val localActor = system.actorOf(Props(classOf[CreationActor], remoteActor) /*, name = "creationActor"*/)
  def doSomething(op: MathOp): Unit = localActor ! op

  def main(args: Array[String]) {
    WorkerLauncher.system("ddbt","127.0.0.1",2552)
    //WorkerLauncher.main(Array[String]()) // launch workers

    println("Started Creation Application")
    while (true) {
      if (Random.nextInt(100) % 2 == 0) doSomething(Multiply(Random.nextInt(20), Random.nextInt(20)))
      else doSomething(Divide(Random.nextInt(10000), (Random.nextInt(99) + 1)))
      Thread.sleep(200)
    }
  }
}

trait MathOp
case class Multiply(nbr1: Int, nbr2: Int) extends MathOp
case class Divide(nbr1: Double, nbr2: Int) extends MathOp

trait MathResult
case class MultiplicationResult(nbr1: Int, nbr2: Int, result: Int) extends MathResult
case class DivisionResult(nbr1: Double, nbr2: Int, result: Double) extends MathResult

class AdvancedCalculatorActor extends Actor {
  def receive = {
    case Multiply(n1, n2) => sender ! MultiplicationResult(n1, n2, n1 * n2)
    case Divide(n1, n2) => sender ! DivisionResult(n1, n2, n1 / n2)
  }
}

